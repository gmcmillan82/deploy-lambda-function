import json
import boto3
import os
from collections import Counter
import urllib.parse

s3 = boto3.client('s3')

def lambda_handler(event, context):
  """
  Processes text to find the most common words (limited to top 10) and generates a pre-signed URL for download
  """

  # Parse request body
  body = json.loads(event['body'])
  text = body.get('text', '')

  # Process the input to find the most common words
  words = text.split()
  word_counts = Counter(words)

  # Limit to top 10 most common words
  top_10_words = word_counts.most_common(10)

  # Prepare the data for the JSON file
  result = {word: count for word, count in top_10_words}

  # Save the result to a JSON file and upload to predefined S3 bucket
  json_data = json.dumps(result, indent=4)
  bucket_name = os.environ['BUCKET_NAME']
  file_name = f"common_words_{context.aws_request_id}.json"
  s3.put_object(Bucket=bucket_name, Key=file_name, Body=json_data)

  # Generate a download link for the JSON file
  file_url = f"https://{bucket_name}.s3.amazonaws.com/{urllib.parse.quote(file_name)}"

  # Return the download link
  return {
      'statusCode': 200,
      'body': json.dumps({'download_link': file_url}),
      'headers': {'Content-Type': 'application/json'}
  }

